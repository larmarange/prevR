.onAttach=function(libname, pkgname)
{
packageStartupMessage(gettext("\n\nWelcome to 'prevR': estimate regional trends of a prevalence.",domain="R-prevR"))
packageStartupMessage(gettext("\t- type help('prevR') for details\n\t- type demo(prevR) for a demonstration\n\t- type citation('prevR') to cite prevR in a publication.\n\n ",domain="R-prevR"))
}