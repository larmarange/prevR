setMethod("print","prevR",
function(x){
   show(x)
   invisible(NULL)
  }
)
